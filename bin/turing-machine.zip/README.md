#Turing Machine in Coffeescript

A port of the [Turing Machine in Processing](https://github.com/Lokidottir/processing-turing-machine) for browsers, written in coffeescript.
